package com.example.shivanii.gamesataclick;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class simple extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple);
    }
    //add 2 buttons. one for how to play and other for bingo intent activity
    public void howtoplay(View v)
    {
        Intent intent=new Intent(this,userSelectBingo.class);

        startActivity(intent);
    }
    public void play(View v)
    {
        Intent in=new Intent(this,bingo.class);

        startActivity(in);
    }
}
